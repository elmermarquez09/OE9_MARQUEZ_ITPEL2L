<?php 
include('connect.php');

session_start();
$id = $_SESSION();
$fname = $_SESSION['fistname'];
$lname = $_SESSION['lastname'];
$session = $_SESSION['logged_in'];

$query = mysqli_query($con,"select id, count(id) as user_count from users_tbl");
$view = mysqli_fetch_array($query);
$user_ctr = $view['user_count'];

if(isset($_GET['delete_id'])){
    $query = "delete from users_tbl where id =".$GET['delete_id'];
    mysqli_query($con,$query);
    header('location:dashboard.php');
}

$image_query = mysqli_query($con, "select * from users_tbl where id ='$id");
?>